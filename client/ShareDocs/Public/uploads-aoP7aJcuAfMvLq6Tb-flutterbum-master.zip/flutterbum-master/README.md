Flutterbum

Deployed at www.flutterbum.com, this application was built in Meteor JS.
There are several videos to walk you through the entire completion of this project.

1. The entire project starts with the Differential Boilerplate
2. The packages added are
  cfs:filesystem
  cfs:standard-packages
  mrt:fullcalendar

Go to http://gumroad.com/geomck1967  to view the videos

The Differential Boilerplate starts editing the seo.js, but Differential has moved to a new package for managing page titles.  To stay with the video, you can add the package back in, or follow the directions in the 
https://github.com/Differential/meteor-boilerplate  under SEO.

meteor add manuelschoebel:ms-seo
